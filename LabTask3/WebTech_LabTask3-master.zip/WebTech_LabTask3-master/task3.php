
<!DOCTYPE html>
<html>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form action="" method="POST">
Date of Birth: <br>
dd<input type="text" name="dd" value="" required>/mm<input type="text" name="mm" value="" required>/yy<input type="text" name="yy" value="" required><br>
<button type="submit" value="Submit">Submit</button>

</form>
</body>
</html>
<?php
 Day: echo ($_POST['dd']);
 Month: echo($_POST['mm']);
 Year: echo($_POST['yy']);
?>
