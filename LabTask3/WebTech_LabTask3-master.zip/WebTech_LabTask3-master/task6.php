<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form action="task6.php" method="POST">
BLOOD GROUP<br>
<select name="Groups"><br>
<option value="A+">A+</option>
<option value="A-">A-</option>
<option value="B+">B+</option>
<option value="B-">B-</option>
<option value="O+">O+</option>
</select><br>


    <input type="submit" name="formSubmit" value="Submit" />

</form>
</body>
</html>
<?php
echo $_POST['Groups'];
?>
