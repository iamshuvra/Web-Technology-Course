<!DOCTYPE html>
<html>
<body>

<form action="task5.php" method="POST">
  <fieldset>
    <legend>DEGREE</legend>
    <input type="checkbox" name="degree" value="ssc">SSC
    <input type="checkbox" name="degree" value="hsc">HSC 
    <input type="checkbox" name="degree" value="bsc">BSc
    <input type="checkbox" name="degree" value="msc">MSc
    <br>
    <input type="submit" value="Submit">
  </fieldset>
</form>

</body>
</html>
<?php 
echo ($_POST['degree']);
?>
